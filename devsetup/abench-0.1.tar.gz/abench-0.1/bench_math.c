#include <stdio.h>
#include <stdlib.h>

#define LOOP_MATH 130

int bench_math_01(int a, int b, int c, int d)
{
        return (a + b) * (c + d);
}

float bench_math_02(float a, float b, float c, float d)
{
        return (a + b) * (c + d);
}

int main_math(int loops)
{
int n0, n1, n2, n3;
int total1;
float total2;

        total1 = 0;
        total2 = 0.0;

        for(n0=0;n0<LOOP_MATH;n0++){
                for(n1=0;n1<LOOP_MATH;n1++){
                        for(n2=0;n2<LOOP_MATH;n2++){
                                for(n3=0;n3<LOOP_MATH;n3++){
                                        total1 += bench_math_01(n0,n1,n2,n3);
                                        total2 += bench_math_02(n0,n1,n2,n3);
                                }
                        }
                }
        }

        fprintf(stdout,"Result: %d %f\n", total1, total2);

	return 0;
}

