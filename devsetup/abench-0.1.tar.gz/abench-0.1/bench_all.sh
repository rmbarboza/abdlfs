#!/bin/sh

time ./abench math
time ./abench rlimit
time ./abench malloc
time ./abench getcwd

