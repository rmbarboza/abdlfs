#include <stdio.h>
#include <stdlib.h>

#define LOOP_MALLOC 5000

int *bench_malloc(int n)
{
int *v;

	v = malloc(sizeof(int)*n);
	v[0] = 1762;
	return v;
}

int main_malloc(int loops)
{
int **v0;
int n0, n1;

        for(n0=0; n0<LOOP_MALLOC; n0++){
		v0 = malloc(sizeof(int *)*LOOP_MALLOC);
                for(n1=0; n1<LOOP_MALLOC; n1++){
			v0[n1] = bench_malloc(27);
                }
                for(n1=0; n1<LOOP_MALLOC; n1++){
			if(v0[n1]) free(v0[n1]);
                }
		free(v0);
        }

	return 0;
}

