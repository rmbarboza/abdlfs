#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define LOOP_GETCWD 3000000

char *bench_getcwd(char *buffer, int size)
{
	getcwd(buffer, size);
	return buffer;
}


int main_getcwd(int loops)
{
int total1, n0;
char buffer[1024];

	total1 = 0;

        for(n0=0;n0<LOOP_GETCWD;n0++){
		bench_getcwd(buffer, 1024);
		total1 += buffer[0];
        }

        fprintf(stdout,"Result: %d\n", total1);
	
	return 0;
}

