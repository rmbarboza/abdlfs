#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main_math(int loops);
int main_rlimit(int loops);
int main_malloc(int loops);
int main_getcwd(int loops);

int usage(char *name)
{
	fprintf(stdout,"Usage: -l <loops> %s <test>\n", name);
	fprintf(stdout," <test> ::=  math | rlimit | malloc | getcwd\n");
}

int exec_test(int (*test)(), int loops)
{
	while(loops-->0){
		test(1);
	}
}

int main(int argc, char **argv)
{
char *test;
int  argcount;
int  loops;

	if(argc<2){
		usage(argv[0]);
		exit(-1);
	}
	
	argcount = 1;

	loops = 1;

	if(!strcmp(argv[argcount],"-l")){
		if(++argcount>=argc){
			usage(argv[0]);
			exit(-1);
		}
		loops = atoi(argv[argcount]);
		if(loops<1) loops=1;
		argcount++;
	}

	if(argcount>=argc){
		usage(argv[0]);
		exit(-1);
	}

	test = argv[argcount];

	fprintf(stdout,"Test: %s, Loops: %d\n", test, loops);

	if(!strcmp(test,"math"))   exec_test(main_math,loops);
	if(!strcmp(test,"rlimit")) exec_test(main_rlimit,loops);
	if(!strcmp(test,"malloc")) exec_test(main_malloc,loops);
	if(!strcmp(test,"getcwd")) exec_test(main_getcwd,loops);
}
